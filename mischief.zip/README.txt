Midnight Mischief Mixer — quick start
-------------------------------------------------
1) Open app.js and paste your Firebase web config in the firebaseConfig block.
   - Firebase Console → Project settings → Your apps (Web) → SDK setup and config.

2) Open index.html in a browser (host screen).
   - Click "Create Room". Share the QR/link with players.

3) On phones, open the link or go to join.html and enter the room code and name.

Optional free hosting:
- GitHub Pages / Netlify / Vercel / Cloudflare Pages / Replit (no build step).
